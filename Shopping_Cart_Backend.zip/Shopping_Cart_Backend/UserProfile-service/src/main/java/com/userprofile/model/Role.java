package com.userprofile.model;

public interface Role {

	public static final String Customer = "ROLE_Customer";
	public static final String merchant = "ROLE_Merchant";
	public static final String deliveryAgent = "ROLE_DeliveryAgent";
}
