package com.websitecontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsiteControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
