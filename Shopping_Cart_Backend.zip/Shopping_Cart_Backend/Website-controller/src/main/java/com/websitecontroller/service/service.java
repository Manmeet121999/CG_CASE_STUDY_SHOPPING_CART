package com.websitecontroller.service;

import org.springframework.http.ResponseEntity;

public interface service {

	ResponseEntity<?> viewProfiles();
	ResponseEntity<?> viewProducts();
}
