package com.cg.shopping.authservice.client;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class ProfileServiceFallback //implements ProfileServiceClient
{
//    @Override
//    public ResponseEntity<UserProfile> addNewCustomer(UserProfile userProfile) {
//        return ResponseEntity.ok(UserProfile.builder().build());
//    }
//
//    @Override
//    public ResponseEntity<UserProfile> login(Map<String, String> userProfile) {
//        return ResponseEntity.ok(UserProfile.builder().build());
//    }
}
